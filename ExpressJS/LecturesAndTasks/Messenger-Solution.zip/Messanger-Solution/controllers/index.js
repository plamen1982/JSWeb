const home = require('./home-controller');
const user = require('./user-controller');
const thread = require('./thread-controller');

module.exports = {
    home,
    user,
    thread
};