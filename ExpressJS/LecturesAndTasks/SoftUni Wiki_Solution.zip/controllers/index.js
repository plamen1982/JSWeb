const home = require('./home-controller');
const user = require('./user-controller');
const article = require('./article-controller');

module.exports = {
    home,
    user,
    article
};