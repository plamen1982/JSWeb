import React from 'react';

const Home = () => {
    return (
        <div>
            <h1>This is the Home page</h1>
        </div>
    );
};

export default Home;