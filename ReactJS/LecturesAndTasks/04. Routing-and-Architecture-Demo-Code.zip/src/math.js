export const add = (a, b) => {
    return a + b;
}

export const subtract = (a, b) => {
    return a - b;
};