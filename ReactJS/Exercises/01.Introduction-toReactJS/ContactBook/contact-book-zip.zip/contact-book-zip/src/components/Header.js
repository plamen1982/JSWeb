import React from 'react';

export default () => <header>&#9993; Contact Book</header>;