import React from 'react';

export default () => <footer>Contact Book SPA &copy; 2019</footer>;
